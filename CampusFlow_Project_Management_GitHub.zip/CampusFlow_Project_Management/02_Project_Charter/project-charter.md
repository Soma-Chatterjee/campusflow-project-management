# Project Charter

## Project Information

| Field | Detail |
|---|---|
| Project | CampusFlow Student Success Initiative |
| Project Manager | Portfolio Project Manager |
| Sponsor | Director of Student Experience |
| Duration | 12 weeks |
| Methodology | Hybrid governance + Agile delivery |
| Illustrative Budget | ₹5,00,000 |
| Primary Users | University students |

## Purpose

To plan and manage delivery of a focused student-success MVP and prepare it for a controlled pilot.

## Objectives

1. Complete the agreed MVP within 12 weeks.
2. Keep budget variance within ±10%.
3. Establish 100% ownership for high-priority risks.
4. Achieve at least 90% UAT acceptance against defined scenarios.
5. Maintain clear stakeholder communication throughout delivery.

## High-Level Deliverables

- Business case
- Requirements baseline
- Project plan
- MVP
- UAT results
- Training and handover materials
- Closure report

## Assumptions

- Required project roles are available when scheduled.
- Stakeholders provide feedback within agreed review windows.
- The MVP can be validated with a representative pilot group.

## Constraints

- Fixed 12-week target
- Controlled budget
- Limited team capacity
- No full-scale enterprise rollout in Phase 1

## Approval Criteria

The project may proceed when sponsor approval, scope baseline, resource assumptions and initial risk assessment are established.

