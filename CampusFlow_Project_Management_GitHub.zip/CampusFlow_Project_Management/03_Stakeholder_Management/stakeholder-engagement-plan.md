# Stakeholder Engagement Plan

| Stakeholder | Information Needed | Channel | Frequency | Owner |
|---|---|---|---|---|
| Sponsor | Overall health, decisions, risks | Status report | Biweekly | PM |
| Students | Feedback and usability needs | Survey / sessions | Weekly during discovery | PM/BA |
| Faculty | Requirements and constraints | Review meeting | Biweekly | PM |
| Administration | Governance and milestones | Steering review | Monthly | PM |
| Delivery Team | Priorities, blockers, dependencies | Stand-up / Jira | Weekly | PM |
| QA | Scope, acceptance criteria, defects | Working session | Weekly | PM/QA |

### Escalation

Issues that threaten a milestone, budget tolerance, or critical acceptance criterion are escalated to the sponsor with a recommendation and impact summary.

