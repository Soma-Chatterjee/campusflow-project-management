# Stakeholder Register

| Stakeholder | Role | Power | Interest | Engagement Strategy |
|---|---|---:|---:|---|
| Director of Student Experience | Sponsor | High | High | Manage closely |
| Project Manager | Delivery owner | High | High | Manage closely |
| Students | Primary users | Medium | High | Consult frequently |
| Faculty | Academic stakeholders | High | Medium | Keep satisfied |
| University Administration | Governance | High | Medium | Keep satisfied |
| Business Analyst | Requirements | Medium | High | Collaborate |
| UX Designer | Design | Medium | High | Collaborate |
| Delivery Team | Implementation | Medium | High | Collaborate |
| QA | Quality | Medium | High | Collaborate |
| Communications | Adoption | Low | Medium | Keep informed |

## Engagement Principles

- High-power stakeholders receive concise decision-oriented updates.
- Students participate through structured feedback rather than ad hoc requests.
- Delivery teams receive clear priorities, decisions and dependency information.
- Stakeholder disagreements are documented and resolved through agreed governance.

