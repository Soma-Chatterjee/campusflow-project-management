# Requirements Management

## Requirements Management Approach

Requirements are captured, prioritized, baselined and linked to acceptance criteria. Changes after baseline require impact assessment.

## Prioritization Method

**MoSCoW**
- Must Have — required for MVP
- Should Have — important but not release-blocking
- Could Have — useful enhancement
- Won't Have — explicitly deferred

## User Stories

| ID | User Story | Priority | Points | Acceptance Summary |
|---|---|---|---:|---|
| US-01 | As a student, I want to create an account so that I can access my workspace. | Must | 3 | Registration succeeds with valid information. |
| US-02 | As a student, I want to sign in securely so that I can access my data. | Must | 3 | Valid credentials provide access. |
| US-03 | As a student, I want to create courses so that my tasks are organized. | Must | 5 | Course can be created, edited and viewed. |
| US-04 | As a student, I want to create assignments so that I can track work. | Must | 5 | Assignment stores title, course, due date and priority. |
| US-05 | As a student, I want to see deadlines on a calendar so that I can plan ahead. | Must | 8 | Tasks with dates appear in calendar view. |
| US-06 | As a student, I want to prioritize tasks so that I can focus on urgent work. | Must | 3 | Priority can be assigned and changed. |
| US-07 | As a student, I want reminders so that I do not miss deadlines. | Should | 8 | Reminder is generated according to configured rule. |
| US-08 | As a student, I want a group-project workspace so that team work is visible. | Should | 13 | Members can view assigned group tasks. |
| US-09 | As a student, I want progress indicators so that I can monitor workload. | Could | 8 | Dashboard summarizes task status. |
| US-10 | As a student, I want advanced recommendations so that I can optimize study time. | Won't / Phase 2 | 13 | Deferred from MVP. |

## Requirement Traceability Principle

Every Must Have requirement should map to:
1. A backlog item
2. An acceptance criterion
3. A test scenario
4. A release decision

