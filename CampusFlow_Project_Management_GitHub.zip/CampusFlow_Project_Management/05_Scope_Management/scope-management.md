# Scope Management

## In Scope

- Discovery and stakeholder engagement
- Requirements definition
- Solution design coordination
- MVP delivery
- User acceptance testing
- Pilot preparation
- Documentation and handover

## Out of Scope

- University-wide deployment
- Payment functionality
- Full LMS replacement
- AI tutoring
- Advanced personalization
- Long-term operational support

## Scope Control

Any material change after baseline must include:
- Business justification
- Scope impact
- Schedule impact
- Budget/resource impact
- Risk impact
- Recommendation
- Sponsor decision

## Definition of Done

A release item is considered complete when:
- Acceptance criteria are met.
- Required testing is completed.
- No unresolved critical defect remains.
- Documentation is updated where applicable.
- Stakeholder acceptance is recorded.

