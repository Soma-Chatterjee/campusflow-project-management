# Project Roadmap

| Phase | Weeks | Key Outputs |
|---|---|---|
| Initiation | 1–2 | Charter, governance, stakeholder map |
| Discovery | 2–3 | Research, requirements |
| Planning | 3–4 | Scope, WBS, schedule, budget, risks |
| Execution | 5–9 | Design, delivery, reviews |
| Validation | 10–11 | UAT, fixes, acceptance |
| Closure | 12 | Handover, lessons learned, closure |

## Milestones

| Milestone | Target |
|---|---|
| Charter approved | End Week 1 |
| Requirements baseline | End Week 3 |
| Delivery plan approved | End Week 4 |
| MVP feature-complete | End Week 9 |
| UAT complete | End Week 11 |
| Project closure | End Week 12 |

