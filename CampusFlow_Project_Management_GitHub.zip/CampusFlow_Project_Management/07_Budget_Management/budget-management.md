# Budget Management

The project uses an illustrative ₹5,00,000 budget ceiling with a ±10% variance tolerance.

Budget control principles:
- Track planned versus illustrative actuals.
- Flag categories exceeding tolerance.
- Preserve contingency for approved risks.
- Escalate forecast overrun before the budget ceiling is breached.
- Do not treat simulated figures as real financial claims.

