# Resource Management

Resource planning is based on role clarity, capacity and timing rather than technical specialization.

The Project Manager monitors:
- Availability
- Capacity
- Critical dependencies
- Approval bottlenecks
- Workload conflicts
- Escalation needs

