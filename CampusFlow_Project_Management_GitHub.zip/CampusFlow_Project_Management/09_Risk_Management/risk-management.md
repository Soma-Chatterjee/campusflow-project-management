# Risk Management

## Risk Scoring

Probability and impact are scored qualitatively. The portfolio uses a simple 1–9 illustrative risk score for prioritization.

### Response Types

- Avoid
- Mitigate
- Transfer
- Accept
- Monitor

High-priority risks receive a named owner and mitigation plan.

