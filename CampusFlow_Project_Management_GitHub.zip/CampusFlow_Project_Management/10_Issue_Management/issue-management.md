# Issue Management

Issues are tracked separately from risks because they represent events that have already occurred.

Each issue receives:
- Impact assessment
- Priority
- Owner
- Action
- Status
- Escalation path when required

