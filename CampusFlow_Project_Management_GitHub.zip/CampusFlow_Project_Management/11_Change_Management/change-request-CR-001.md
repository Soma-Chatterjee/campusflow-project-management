# Change Request CR-001

## Requested Change

Add an AI-powered study planner to the MVP before launch.

| Dimension | Assessment |
|---|---|
| Business value | High |
| Scope impact | High |
| Schedule impact | +3 weeks |
| Illustrative budget impact | +₹75,000 |
| Resource impact | Additional specialist capability |
| Risk impact | High |

## Recommendation

**Defer to Phase 2.**

## Decision Rationale

The feature may create strategic value, but introducing it during the MVP delivery window would materially increase scope, schedule and resource pressure. Protecting the committed MVP timeline provides a better project outcome.

## Governance

The decision should be recorded in the change log and communicated to affected stakeholders. The feature remains eligible for Phase 2 discovery.

