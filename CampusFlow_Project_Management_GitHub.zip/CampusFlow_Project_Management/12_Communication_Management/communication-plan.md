# Communication Plan

| Audience | Message | Frequency | Format | Owner |
|---|---|---|---|---|
| Sponsor | Overall health, decisions, risks | Biweekly | Executive status report | PM |
| Delivery team | Priorities, blockers, dependencies | Weekly | Working session | PM |
| Students | Research and feedback | Weekly in discovery | Survey/session | PM/BA |
| Faculty | Requirements and constraints | Biweekly | Review | PM |
| Administration | Governance and milestones | Monthly | Steering update | PM |

## Communication Principles

1. Lead with decisions and risks.
2. Separate facts from assumptions.
3. Assign an owner and due date to actions.
4. Escalate only with context and a recommendation.
5. Keep executive updates concise.

