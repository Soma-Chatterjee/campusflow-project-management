# Agile Execution

## Delivery Model

Project governance remains responsible for scope, schedule, budget, risks and stakeholder decisions. Agile is used within the execution workstream to deliver and review increments.

## Sprint Structure

- Sprint Planning
- Weekly coordination
- Sprint Review
- Retrospective
- Backlog refinement

## Sprint Goals

| Sprint | Goal |
|---|---|
| 1 | Establish foundation |
| 2 | Deliver academic management |
| 3 | Deliver calendar and prioritization |
| 4 | Deliver reminders |
| 5 | Deliver collaboration |
| 6 | Prepare release |

## Management Focus

The PM monitors capacity, dependencies, blockers, stakeholder decisions and delivery health rather than acting as the technical lead.

