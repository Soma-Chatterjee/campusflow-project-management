# Sprint Retrospective

## What Went Well

- Requirements were clearer after early stakeholder reviews.
- Weekly coordination surfaced blockers early.
- Scope decisions were documented.

## What Did Not Go Well

- Design approval took longer than planned.
- Collaboration work had higher uncertainty than estimated.

## Actions

| Action | Owner | Timing |
|---|---|---|
| Add approval deadlines to milestone plan | PM | Next sprint |
| Review capacity before committing to collaboration work | PM + Delivery Lead | Next planning |
| Continue decision log | PM | Ongoing |

