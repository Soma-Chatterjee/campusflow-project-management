# Project Dashboard Guide

The dashboard provides an executive-level view of schedule, budget, scope, risk, quality and stakeholder health.

### RAG Logic

- Green: within agreed tolerance
- Amber: requires management attention
- Red: threatens a major project objective or requires escalation

