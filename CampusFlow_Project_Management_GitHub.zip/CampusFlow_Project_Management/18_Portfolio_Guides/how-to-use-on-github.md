# GitHub Upload Guide

1. Create a public repository named `campusflow-project-management`.
2. Upload the entire folder structure.
3. Keep `README.md` at the repository root.
4. Add screenshots of the dashboard, stakeholder matrix, risk register and executive presentation cover if desired.
5. Add a short repository description: `End-to-end project management portfolio simulation demonstrating stakeholder, scope, schedule, budget, risk, Agile delivery and change management.`
6. Pin the repository on your GitHub profile.
7. Use the repository link in your resume under Projects.

## Important

Do not describe the simulated project as employment, client work or an actual production launch. Present it as a portfolio case study demonstrating your project-management approach.

