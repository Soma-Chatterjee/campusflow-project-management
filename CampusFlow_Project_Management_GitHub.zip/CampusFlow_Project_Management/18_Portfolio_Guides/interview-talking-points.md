# Interview Talking Points

## 60-Second Overview

CampusFlow is an end-to-end project management simulation in which I acted as Project Manager for a student-success initiative. I developed the business case and charter, mapped stakeholders, defined scope and requirements, planned schedule, budget and resources, and established risk and communication controls. I then used Agile practices for execution, monitored project health, assessed a significant scope-change request and recommended deferring it to Phase 2 to protect the MVP timeline. The project concludes with UAT, closure and lessons learned.

## Strongest Management Examples

### Stakeholder Management
I separated stakeholders by influence and interest and tailored communication to their decision needs.

### Scope Management
I created explicit in-scope and out-of-scope boundaries and required impact analysis for material changes.

### Risk Management
I assigned owners and mitigation plans to high-priority risks rather than simply listing them.

### Change Management
I assessed the AI feature request across scope, schedule, budget, resources and risk before recommending deferral.

### Communication
I used concise status reporting with RAG indicators, decisions required and next actions.

### Leadership
I focused on alignment, decision-making, escalation and delivery visibility rather than technical execution.

