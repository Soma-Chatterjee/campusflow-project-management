# Portfolio Disclosure

CampusFlow is a simulated project-management case study created for portfolio and interview demonstration. Financial figures, schedules, staffing assumptions, KPIs and outcomes are illustrative. They should not be represented as actual client, employer or production results.
